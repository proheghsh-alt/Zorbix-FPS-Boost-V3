package com.zorbix.fpsboost;

import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;

public class ZorbixConfig {
    public boolean enabled = true;
    public ZorbixProfile profile = ZorbixProfile.BALANCED;
    public ParticlesMode particles = ParticlesMode.DECREASED;
    public CloudRenderMode clouds = CloudRenderMode.OFF;
    public GraphicsMode graphics = GraphicsMode.FAST;
    public boolean ambientOcclusion = false;
    public boolean entityShadows = false;
    public boolean weatherEffects = true;
    public boolean viewBobbing = true;
    public boolean fovEffects = true;
    public boolean fog = true;

    public static ZorbixConfig forProfile(ZorbixProfile profile) {
        ZorbixConfig c = new ZorbixConfig();
        c.profile = profile;
        switch (profile) {
            case SAFE -> {
                c.particles = ParticlesMode.ALL;
                c.clouds = CloudRenderMode.FANCY;
                c.graphics = GraphicsMode.FANCY;
                c.ambientOcclusion = true;
                c.entityShadows = true;
            }
            case BALANCED -> {}
            case PERFORMANCE -> c.particles = ParticlesMode.MINIMAL;
            case ULTRA_LOW -> {
                c.particles = ParticlesMode.MINIMAL;
                c.weatherEffects = false;
                c.viewBobbing = false;
                c.fovEffects = false;
                c.fog = false;
            }
            case CUSTOM -> {}
        }
        return c;
    }
}
