package com.zorbix.fpsboost;

public enum ZorbixProfile {
    SAFE, BALANCED, PERFORMANCE, ULTRA_LOW, CUSTOM
}
