package com.zorbix.fpsboost;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;

public class FpsBoostClient implements ClientModInitializer {
    private final ZorbixConfig config = ZorbixConfig.forProfile(ZorbixProfile.BALANCED);
    private boolean applied;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);
    }

    private void onClientTick(MinecraftClient client) {
        if (!config.enabled || client.options == null || applied) return;

        // V3: apply once. No FPS-based distance changes and no chunk reload loop.
        client.options.getParticles().setValue(config.particles);
        client.options.getCloudRenderMode().setValue(config.clouds);
        client.options.getGraphicsMode().setValue(config.graphics);
        client.options.getAo().setValue(config.ambientOcclusion);
        client.options.getEntityShadows().setValue(config.entityShadows);
        client.options.getBobView().setValue(config.viewBobbing);
        client.options.getFovEffectScale().setValue(config.fovEffects ? 1.0 : 0.0);

        applied = true;
    }
}
